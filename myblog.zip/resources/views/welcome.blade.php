<!DOCTYPE html>
<html lang="en">
<head>
    @include('partials.head')
    <link rel="stylesheet" href="{{asset('css/page.css')}}">
</head>
<body>

@include('partials.nav')


@include('partials.footer')
@include('partials.js')

</body>
</html>
