</div>
</div>
<?php /**PATH C:\Users\Hp\Desktop\mdb\myblog\resources\views/partials/footer.blade.php ENDPATH**/ ?>